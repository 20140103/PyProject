#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from gui import App

app = App()